<?php

include __DIR__ . '/vendor/autoload.php';

//include "src/api/random-animail.phtml";
